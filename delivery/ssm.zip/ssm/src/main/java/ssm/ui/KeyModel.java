package ssm.ui;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import ssm.util.*;

import javax.swing.event.EventListenerList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static ssm.util.Des.*;

public class KeyModel {
    private static final Log log = LogFactory.getLog(KeyModel.class);

    protected PreparedStatement ps = null;
    protected EventListenerList listenerList = new EventListenerList();
    protected Connection con;

    protected static KeyTree keyTree;

    // This connection is used by UI
    public KeyModel() {
        con = JDBCConnection.getInstance().getConnection();
    }

    // This connection is used by workder threads.
    public KeyModel(int unused) throws SQLException {
        con = JDBCConnection.getInstance().connect();
    }

    public boolean insertKey(KeyBean clearKey) {
        try {
            KeyBean encryptedKey = keyTree.insertKey(clearKey);
            ps = con.prepareStatement("INSERT INTO keys VALUES (?,?,?,?,?)");

            ps.setString(1, encryptedKey.getKid());
            ps.setString(2, encryptedKey.getTyp());
            ps.setInt(3, encryptedKey.getKv());
            ps.setString(4, encryptedKey.getKev());
            ps.setString(5, encryptedKey.getKcv());

            ps.executeUpdate();

            con.commit();

            return true;
        } catch (SQLException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);

            try {
                con.rollback();
                return false;
            } catch (SQLException ex2) {
                event = new ExceptionEvent(this, ex2.getMessage());
                fireExceptionGenerated(event);
                return false;
            }
        } catch (KeyException ex) {
            fireExceptionGenerated(new ExceptionEvent(this, ex.getMessage()));
            return false;
        }
    }

    public boolean updateKey(KeyBean clearKey) throws KeyException {
        try {
            KeyBean encryptedKey = keyTree.updateKey(clearKey);
            ps = con.prepareStatement("UPDATE keys SET kev = ?, kcv = ? WHERE entityid = ? and keytype = ? and keyver = ?");

            ps.setString(1, encryptedKey.getKev());
            ps.setString(2, encryptedKey.getKcv());

            ps.setString(3, clearKey.getKid());
            ps.setString(4, clearKey.getTyp());
            ps.setInt(5, clearKey.getKv());

            ps.executeUpdate();

            con.commit();

            return true;
        } catch (SQLException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);

            try {
                con.rollback();
                return false;
            } catch (SQLException ex2) {
                event = new ExceptionEvent(this, ex2.getMessage());
                fireExceptionGenerated(event);
                return false;
            }
        }
    }

    public boolean deleteKey(String entitiyid, String keytype) {
        return deleteKey(entitiyid, keytype, 1, true);
    }

    public boolean deleteKey(String entitiyid, String keytype, int kv) {
        return deleteKey(entitiyid, keytype, kv, true);
    }

    public boolean deleteKey(String entitiyid, String keytype, boolean commit) {
        return deleteKey(entitiyid, keytype, 1, commit);
    }

    // No commit
    public boolean deleteKey(String entitiyid, String keytype, int kv, boolean commit) {
        try {
            ps = con.prepareStatement("DELETE FROM keys WHERE entityid = ? and keytype = ? and keyver = ?");

            ps.setString(1, entitiyid);
            ps.setString(2, keytype);
            ps.setInt(3, kv);

            ps.execute();

            if (commit)
                con.commit();

            return true;
        } catch (SQLException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);

            try {
                if (commit)
                    con.rollback();
                return false;
            } catch (SQLException ex2) {
                event = new ExceptionEvent(this, ex2.getMessage());
                fireExceptionGenerated(event);
                return false;
            }
        }
    }

    public KeyTree showKeys(int i) {
        try {
            ps = con.prepareStatement("SELECT k.* FROM keys k", ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = ps.executeQuery();

            keyTree.BuildTree(rs);
            return keyTree;
        } catch (SQLException | KeyException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);
            return null;
        }
    }

    public KeyTree loadKeys() {
        try {
            keyTree = KeyTree.getInstance();
            ps = con.prepareStatement("SELECT k.* FROM keys k", ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = ps.executeQuery();

            keyTree.BuildTree(rs);
            return keyTree;
        } catch (SQLException | KeyException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);
            return null;
        }
    }

    public ResultSet editKey() {
        try {
            ps = con.prepareStatement("SELECT k.* FROM keys k", ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);

            ResultSet rs = ps.executeQuery();

            return rs;
        } catch (SQLException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);
            return null;
        }
    }

    public boolean findKey(String entityid, String keytype) {
        return findKey(entityid, keytype, 1);
    }

    public boolean findKey(String entityid, String keytype, int kv) {
        try {
            ps = con.prepareStatement("SELECT kcv FROM keys where entityid = ? and keytype = ? and keyver = ?");

            ps.setString(1, entityid);
            ps.setString(2, keytype);
            ps.setInt(3, kv);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            ExceptionEvent event = new ExceptionEvent(this, ex.getMessage());
            fireExceptionGenerated(event);

            return false;
        }
    }

    public KeyBean getKey(String entityid, String keytype) {
        return getKey(entityid, keytype, 1);
    }

    public KeyBean getKey(String entityid, String keytype, int kv) {
        try {
            ps = con.prepareStatement("SELECT * FROM keys where entityid = ? and keytype = ? and keyver = ?");

            ps.setString(1, entityid);
            ps.setString(2, keytype);
            ps.setInt(3, kv);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new KeyBean(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5));
            } else {
                return null;
            }
        } catch (SQLException ex) {
            fireExceptionGenerated(new ExceptionEvent(this, ex.getMessage()));

            return null;
        }
    }

    public void InitTMK(String atmID) {
        // Generate New Key, encrypted by TMK.INIT
        // If ATM is already has a TMK, then delete it.
        if (findKey(atmID, "TMK")) {
            if (!deleteKey(atmID, "TMK", false)) {
                log.debug("Delete existing TMK failed");
                fireExceptionGenerated(new ExceptionEvent(this, "Delete existing TMK failed"));
            }

        }
        if (findKey(atmID, "TPK")) {
            if (!deleteKey(atmID, "TPK", false)) {
                log.debug("Delete existing TPK failed");
                fireExceptionGenerated(new ExceptionEvent(this, "Delete existing TPK failed"));
            }
        }

        String newKey = randomKey();
        KeyBean kb = new KeyBean(atmID, "TMK", 1, newKey, Enc(newKey, "0000000000000000").substring(0, 6));
        if (!insertKey(kb)) {
            log.debug("InitTMK failed");
        }
    }

    public KeyBean ExchTMK(String atmID) throws KeyException {
        // Generate New Key, encrypted by current TMK
        KeyBean currentTMK = getKey(atmID, "TMK");
        if (currentTMK == null) {
            log.debug("ATM TMK isn't inited");
            fireExceptionGenerated(new ExceptionEvent(this, "ATM TMK isn't inited"));
            throw new KeyException("ATM TMK isn't inited");
        }

        String newKey = randomKey();
        KeyBean newTMK = new KeyBean(atmID, "TMK", 1, newKey, Enc(newKey, "0000000000000000").substring(0, 6));
        updateKey(newTMK);

        return currentTMK;
    }

    public KeyBean ExchTPK(String atmID) throws KeyException {
        // Generate New Key, encrypted by current TPK
        KeyBean currentTMK = getKey(atmID, "TMK");
        if (currentTMK == null)
            throw new KeyException("ATM TMK isn't inited");
        String newKey = randomKey();
        KeyBean newTMK = new KeyBean(atmID, "TPK", 1, newKey, Enc(newKey, "0000000000000000").substring(0, 6));
        if (findKey(atmID, "TPK"))
            updateKey(newTMK);
        else
            insertKey(newTMK);

        return currentTMK;
    }

    public String TransPIN(String atmID, String entityID, String PINBlock) throws KeyException {
        // Generate New Key, encrypted by current TMK
        KeyBean TPK = getKey(atmID, "TPK");
        if (TPK == null)
            throw new KeyException("ATM TPK doesn't exist");
        KeyBean ZPK = getKey(entityID, "ZPK");
        if (ZPK == null)
            throw new KeyException("ZPK doesn't exist for " + entityID);

        String clearPB = Dec(LMKDec(TPK.getKev()), PINBlock);
        return Enc(LMKDec(ZPK.getKev()), clearPB);
    }

    public void TransPIN(CmdBean cb) throws KeyException {
        // Generate New Key, encrypted by current TMK
        KeyBean TPK = getKey(cb.getATMID(), "TPK");
        if (TPK == null) {
            cb.setErrorCode("01");
            throw new KeyException("ATM TPK doesn't exist");
        }
        KeyBean ZPK = getKey(cb.getEntityID(), "ZPK");
        if (ZPK == null) {
            cb.setErrorCode("02");
            throw new KeyException("ZPK doesn't exist for " + cb.getEntityID());
        }

        String clearPB = Dec(LMKDec(TPK.getKev()), cb.getPINBlock());
        cb.setData(Enc(LMKDec(ZPK.getKev()), clearPB));
        cb.setErrorCode("00");
    }

    public String GetClearPIN(String atmID, String PINBlock) throws KeyException {
        // Generate New Key, encrypted by current TMK
        KeyBean TPK = getKey(atmID, "TPK");
        if (TPK == null)
            throw new KeyException("ATM TPK doesn't exist");

        String clearPB = Dec(LMKDec(TPK.getKev()), PINBlock);
        return clearPB;
    }

    public void GetClearPIN(CmdBean cb) throws KeyException, DataException {
        // Generate New Key, encrypted by current TMK
        KeyBean TPK = getKey(cb.getATMID(), "TPK");
        if (TPK == null) {
            cb.setErrorCode("01");
            throw new KeyException("ATM TPK doesn't exist");
        }

        try {
            cb.setData(GetPin(cb.getPan(), Dec(LMKDec(TPK.getKev()), cb.getPINBlock())));
        } catch (DataException e) {
            cb.setErrorCode("02");
            throw e;
        } catch (KeyException e) {
            cb.setErrorCode("01");
            throw e;
        }
        cb.setErrorCode("00");
        return;
    }

    public void GenPVV(CmdBean cb) throws KeyException, DataException {
        KeyBean PVK = getKey("99999999", "PVK", Integer.parseInt(cb.getPVKI()));
        if (PVK == null) {
            cb.setErrorCode("01");
            throw new KeyException("PVK doesn't exist");
        }

        KeyBean ZPK = getKey("99999999", "ZPK");
        if (ZPK == null) {
            cb.setErrorCode("02");
            throw new KeyException("ZPK doesn't exist for " + cb.getEntityID());
        }
        String clearPB = Dec(LMKDec(ZPK.getKev()), cb.getPINBlock());
        String clearPIN = GetPinFromISO0(cb.getPan(), clearPB);
        String TSP = cb.getPan().substring(cb.getPan().length() - 12, cb.getPan().length() - 1) + cb.getPVKI() + clearPIN.substring(0, 4);

        String encryptedTSP = Enc(LMKDec(PVK.getKev()), TSP);
        char[] ttt = encryptedTSP.toCharArray();
        char[] pvv = new char[4];

        int pvv_offset = 0;
        for (int i = 0; i < ttt.length; ++i) {
            if (ttt[i] <= '9' && ttt[i] >= '0') {
                pvv[pvv_offset++] = ttt[i];
                if (pvv_offset == 4)
                    break;
            }
        }
        if (pvv_offset < 4) {
            for (int i = 0; i < ttt.length; ++i) {
                if (ttt[i] >= 'A' && ttt[i] <= 'F') {
                    switch (ttt[i]) {
                        case 'A':
                            pvv[pvv_offset++] = '0';
                            break;
                        case 'B':
                            pvv[pvv_offset++] = '1';
                            break;
                        case 'C':
                            pvv[pvv_offset++] = '2';
                            break;
                        case 'D':
                            pvv[pvv_offset++] = '3';
                            break;
                        case 'E':
                            pvv[pvv_offset++] = '4';
                            break;
                        case 'F':
                            pvv[pvv_offset++] = '5';
                            break;
                    }

                    if (pvv_offset == 4)
                        break;
                }
            }
        }
        cb.setData(String.valueOf(pvv));
        cb.setErrorCode("00");
    }

    public void VerPVV(CmdBean cb) throws KeyException, DataException {
        KeyBean PVK = getKey("99999999", "PVK", Integer.parseInt(cb.getPVKI()));
        if (PVK == null) {
            cb.setErrorCode("01");
            throw new KeyException("PVK doesn't exist");
        }

        KeyBean ZPK = getKey("99999999", "ZPK");
        if (ZPK == null) {
            cb.setErrorCode("02");
            throw new KeyException("ZPK doesn't exist for " + cb.getEntityID());
        }
        String clearPB = Dec(LMKDec(ZPK.getKev()), cb.getPINBlock());
        String clearPIN = GetPinFromISO0(cb.getPan(), clearPB);
        String TSP = cb.getPan().substring(cb.getPan().length() - 12, cb.getPan().length() - 1) + cb.getPVKI() + clearPIN.substring(0, 4);

        String encryptedTSP = Enc(LMKDec(PVK.getKev()), TSP);
        char[] ttt = encryptedTSP.toCharArray();
        char[] pvv = new char[4];

        int pvv_offset = 0;
        for (int i = 0; i < ttt.length; ++i) {
            if (ttt[i] <= '9' && ttt[i] >= '0') {
                pvv[pvv_offset++] = ttt[i];
                if (pvv_offset == 4)
                    break;
            }
        }
        if (pvv_offset < 4) {
            for (int i = 0; i < ttt.length; ++i) {
                if (ttt[i] >= 'A' && ttt[i] <= 'F') {
                    switch (ttt[i]) {
                        case 'A':
                            pvv[pvv_offset++] = '0';
                            break;
                        case 'B':
                            pvv[pvv_offset++] = '1';
                            break;
                        case 'C':
                            pvv[pvv_offset++] = '2';
                            break;
                        case 'D':
                            pvv[pvv_offset++] = '3';
                            break;
                        case 'E':
                            pvv[pvv_offset++] = '4';
                            break;
                        case 'F':
                            pvv[pvv_offset++] = '5';
                            break;
                    }

                    if (pvv_offset == 4)
                        break;
                }
            }
        }
        if (cb.getPVV().equals(String.valueOf(pvv)))
            cb.setErrorCode("00");
        else
            cb.setErrorCode("03");
    }

    public void GenCVV(CmdBean cb) throws KeyException, DataException {
        KeyBean CVK = getKey("99999999", "CVK");
        if (CVK == null) {
            cb.setErrorCode("01");
            throw new KeyException("CVK doesn't exist");
        }
        String data = cb.getPan() + cb.getExprDate() + cb.getSvcCode();
        data += String.format("%0" + (32 - data.length()) + "d", 0);

        String d1 = data.substring(0, 16);
        String d2 = data.substring(16, 32);

        String ed1 = Enc1(LMKDec(CVK.getKev()), d1);
        String xo1 = logic(logic_op.xor, ed1, d2);

        String key = LMKDec(CVK.getKev());
        String ed2 = Enc(key, xo1);

        char cvv[] = new char[4];
        char[] ttt = ed2.toCharArray();

        int cvv_offset = 0;
        for (int i = 0; i < ttt.length; ++i) {
            if (ttt[i] <= '9' && ttt[i] >= '0') {
                cvv[cvv_offset++] = ttt[i];
                if (cvv_offset == 3)
                    break;
            }
        }
        if (cvv_offset < 3) {
            for (int i = 0; i < ttt.length; ++i) {
                if (ttt[i] >= 'A' && ttt[i] <= 'F') {
                    switch (ttt[i]) {
                        case 'A':
                            cvv[cvv_offset++] = '0';
                            break;
                        case 'B':
                            cvv[cvv_offset++] = '1';
                            break;
                        case 'C':
                            cvv[cvv_offset++] = '2';
                            break;
                        case 'D':
                            cvv[cvv_offset++] = '3';
                            break;
                        case 'E':
                            cvv[cvv_offset++] = '4';
                            break;
                        case 'F':
                            cvv[cvv_offset++] = '5';
                            break;
                    }

                    if (cvv_offset == 3)
                        break;
                }
            }
        }
        cb.setData(String.valueOf(cvv));
        cb.setErrorCode("00");
    }

    public void VerCVV(CmdBean cb) throws KeyException, DataException {
        KeyBean CVK = getKey("99999999", "CVK");
        if (CVK == null) {
            cb.setErrorCode("01");
            throw new KeyException("CVK doesn't exist");
        }
        String data = cb.getPan() + cb.getExprDate() + cb.getSvcCode();
        data += String.format("%0" + (32 - data.length()) + "d", 0);

        String d1 = data.substring(0, 16);
        String d2 = data.substring(16, 32);

        String ed1 = Enc1(LMKDec(CVK.getKev()), d1);
        String xo1 = logic(logic_op.xor, ed1, d2);

        String key = LMKDec(CVK.getKev());
        String ed2 = Enc(key, xo1);

        char cvv[] = new char[3];
        char[] ttt = ed2.toCharArray();

        int cvv_offset = 0;
        for (int i = 0; i < ttt.length; ++i) {
            if (ttt[i] <= '9' && ttt[i] >= '0') {
                cvv[cvv_offset++] = ttt[i];
                if (cvv_offset == 3)
                    break;
            }
        }
        if (cvv_offset < 3) {
            for (int i = 0; i < ttt.length; ++i) {
                if (ttt[i] >= 'A' && ttt[i] <= 'F') {
                    switch (ttt[i]) {
                        case 'A':
                            cvv[cvv_offset++] = '0';
                            break;
                        case 'B':
                            cvv[cvv_offset++] = '1';
                            break;
                        case 'C':
                            cvv[cvv_offset++] = '2';
                            break;
                        case 'D':
                            cvv[cvv_offset++] = '3';
                            break;
                        case 'E':
                            cvv[cvv_offset++] = '4';
                            break;
                        case 'F':
                            cvv[cvv_offset++] = '5';
                            break;
                    }

                    if (cvv_offset == 3)
                        break;
                }
            }
        }
        if (cb.getCVV().equals(String.valueOf(cvv)))
            cb.setErrorCode("00");
        else
            cb.setErrorCode("03");
    }

    public void GenMAC(CmdBean cb) throws KeyException, DataException {
        KeyBean MCK = getKey("99999999", "MCK");
        if (MCK == null) {
            cb.setErrorCode("01");
            throw new KeyException("MCK doesn't exist");
        }
        String key = LMKDec(MCK.getKev());

        String data = PadData(cb.getMACPaddingMethod(), cb.getMACData());

        cb.getMACAlgorithm();

        String mac = CalMAC(key, data);
        cb.setErrorCode("00");
        cb.setData(mac.substring(0, 8));
    }

    public void VerMAC(CmdBean cb) throws KeyException, DataException {
        KeyBean MCK = getKey("99999999", "MCK");
        if (MCK == null) {
            cb.setErrorCode("01");
            throw new KeyException("MCK doesn't exist");
        }
        String key = LMKDec(MCK.getKev());

        String data = PadData(cb.getMACPaddingMethod(), cb.getMACData());

        cb.getMACAlgorithm();

        String mac = CalMAC(key, data);
        if (cb.getMAC().equalsIgnoreCase(mac.substring(0, 8)))
            cb.setErrorCode("00");
        else
            cb.setErrorCode("03");
    }

    protected void finalize() throws Throwable {
        if (ps != null) {
            ps.close();
        }
        if (con != null) {
            con.close();
        }
        super.finalize();
    }

    public void addExceptionListener(ExceptionListener l) {
        listenerList.add(ExceptionListener.class, l);
    }

    public void removeExceptionListener(ExceptionListener l) {
        listenerList.remove(ExceptionListener.class, l);
    }

    public void fireExceptionGenerated(ExceptionEvent ex) {
        Object[] listeners = listenerList.getListenerList();

        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == ExceptionListener.class) {
                ((ExceptionListener) listeners[i + 1]).exceptionGenerated(ex);
            }
        }
    }
}
