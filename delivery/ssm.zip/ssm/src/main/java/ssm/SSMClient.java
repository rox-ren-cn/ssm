package ssm;

import javax.swing.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

//import javax.swing.JOptionPane;

public class SSMClient {

    InputStream is;
    OutputStream os;
    private JFrame frame = new JFrame("Capitalize Client");
    private JTextField dataField = new JTextField(40);
    private JTextArea messageArea = new JTextArea(8, 60);

    public SSMClient() {
        messageArea.setEditable(false);
        frame.getContentPane().add(dataField, "North");
        frame.getContentPane().add(new JScrollPane(messageArea), "Center");

        dataField.addActionListener(e -> {
            String msg;
            try {
                switch (dataField.getText()) {
                    case "1":
                        msg = "RPIMIM10001004";
                        break;
                    case "2":
                        msg = "PRIMXK010001004";
                        break;
                    case "3":
                        msg = "PRIMXK110001004";
                        break;
                    case "4":
                        msg = "PRIMTP10001004888888880000000000000000";
                        break;
                    case "5":
//                        msg = "PRIMCP1000100400000000000000000001?65>?1?7<?:9<66";
//                        msg = "PRIMCP1000100400000000000000000001F65EF1F7CFA9C66";
                        msg = "PRIMCP100010040000000000000000000CE894149CC2DADAE";
                        break;
                    case "6":
                        msg = "RPIMIM88888888";
                        break;
                    case "7":
                        msg = "PRIMXK088888888";
                        break;
                    case "8":
                        msg = "PRIMXK188888888";
                        break;
                    case "gp": // GenPVV
                        //ZPK=33333333333333333333333333333333 ADC67D
                        //PVK=4CA2161637D0133E5E151AEA45DA2A16 72A5D4
                        //ISO0=0000912345678901^06387283FFFFFFFF=0638E3A0BA9876FE
                        //PINBLOCK=A05DB95641C04183
                        //PVKI=3
                        msg = "PRIMGP34839123456789019   A05DB95641C04183";
                        break;
                    case "vp": // VerPVV
                        //ZPK=33333333333333333333333333333333 ADC67D
                        //PVK=4CA2161637D0133E5E151AEA45DA2A16 72A5D4
                        //ISO0=0000912345678901^06387283FFFFFFFF=0638E3A0BA9876FE
                        //PINBLOCK=A05DB95641C04183
                        //PVKI=3
                        //PVV=3691
                        msg = "PRIMVP34839123456789019   A05DB95641C041833691";
                        break;
                    case "gc": // GenCVV
                        // CVK = 0123456789ABCDEF FEDCBA9876543210
                        // PAN = 4123456789012345
                        // ExprDate = 8701
                        // SvcCode = 111
                        // CVV = 856
                        msg = "PRIMGC4123456789012345   8701111";
                        break;
                    case "vc1": // VerCVV
                        msg = "PRIMVC4123456789012345   8701111856";
                        break;
                    case "vc2": // VerCVV
                        msg = "PRIMVC4999988887777000   9105111245";
                        break;
                    case "vc3": // VerCVV
                        msg = "PRIMVC4666655554444111   9206120664";
                        break;
                    case "cv4": // VerCVV
                        msg = "PRIMVC4333322221111222   9307141382";
                        break;
                    case "gm1": // GenMAC Padding method 1
                        msg = "PRIMGM210160000000000000000";
                        break;
                    case "vm1": // VerMAC Padding method 1
                        msg = "PRIMVM210160000000000000000ADC67D84";
                        break;

                    case "gm2": // GenMAC Padding method 2
                        msg = "PRIMGM220160000000000000000";
                        break;
                    case "vm2": // VerMAC Padding method 2
                        msg = "PRIMVM220160000000000000000E5E4D47A";
                        break;

                    default:
                        msg = "PRIMIM12345678";
                }
                os.write(msg.getBytes(), 0, msg.length());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            String response;
            try {
                byte[] b = new byte[100];
                int len = is.read(b, 0, 100);
                response = new String(b, 0, len);
                if (response == null || response.equals("")) {
                    System.exit(0);
                }
            } catch (IOException ex) {
                response = "Error: " + ex;
            }
            messageArea.append(response + "\n");
            dataField.selectAll();
        });
    }

    public void connectToServer() throws IOException {
        // String serverAddress = JOptionPane.showInputDialog(
        // frame,
        // "Enter IP Address of the Server:",
        // "Welcome to the Capitalization Program",
        // JOptionPane.QUESTION_MESSAGE);
        String serverAddress = "localhost";

        @SuppressWarnings("resource")
        Socket socket = new Socket(serverAddress, 12345);
        is = socket.getInputStream();
        os = socket.getOutputStream();
    }

    public static void main(String[] args) throws Exception {
        SSMClient client = new SSMClient();
        client.connectToServer();
        client.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client.frame.pack();
        client.frame.setVisible(true);
    }
}