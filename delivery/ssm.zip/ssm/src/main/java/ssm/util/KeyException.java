package ssm.util;

public class KeyException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public KeyException(String s) {
		super(s);
	}
}
