package ssm.util;

public class CmdException extends Exception {

	public CmdException(String string) {
		super(string);
	}

	private static final long serialVersionUID = 1L;

}
