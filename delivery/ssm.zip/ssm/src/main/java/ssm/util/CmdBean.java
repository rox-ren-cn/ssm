/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ssm.util;

/**
 * @author Rox
 */
public class CmdBean {

    public static final String INIT_TMK = "IM";
    public static final String EXCH_TXK = "XK";
    public static final String TRNS_PIN = "TP";
    public static final String CLR_PIN = "CP";
    public static final String GEN_PVV = "GP";
    public static final String VER_PVV = "VP";
    public static final String GEN_CVV = "GC";
    public static final String VER_CVV = "VC";
    public static final String GEN_MAC = "GM";
    public static final String VER_MAC = "VM";
    public static final String GEN_ARQC = "GQ";
    public static final String VER_ARQC = "VQ";
    public static final String GEN_ARPC = "GR";
    public static final String VER_ARPC = "VR";

    public static final String EC_OK = "00";
    public static final String EC_BADTMK = "01";
    public static final String EC_BADTMK2 = "02";
    public static final String EC_BADTPK = "03";
    public static final String EC_BADZPK = "04";
    public static final String EC_BADPIN = "05";
    public static final String EC_BADMOD = "06";
    public static final String EC_UNKNOWN = "99";

    public static final String LOCALENTITY = "99999999";

    public static final String REQ_HEADER = "PRIM";
    public static final String RSP_HEADER = "PRIM";

    private String Command;

    public void setErrorCode(String ErrorCode) {
        this.ErrorCode = ErrorCode;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public String getCmd() {
        return Command;
    }

    public String getATMID() {
        return ATMID;
    }

    public String getEntityID() {
        return EntityID;
    }

    public String getMode() {
        return Mode;
    }

    public String getPINBlock() {
        return PINBlock;
    }

    public String getPVKI() {
        return PVKI;
    }

    public String getPan() {
        return Pan.trim();
    }

    public String getExprDate() {
        return ExprDate;
    }

    public String getSvcCode() {
        return SvcCode;
    }

    public String getPVV() {
        return PVV;
    }

    public String getCVV() {
        return CVV;
    }

    public String getMAC() {
        return MAC;
    }

    public String getMACPaddingMethod() {
        return MACPaddingMethod;
    }

    public String getMACAlgorithm() {
        return MACAlgorithm;
    }

    public String getMACData() {
        return MACData;
    }

    private String ATMID;
    private String EntityID;
    private String Mode;
    private String PINBlock;
    private String Pan;
    private String PVKI;
    private String ExprDate;
    private String SvcCode;
    private String PVV;
    private String CVV;
    private String ErrorCode;
    private String Data;
    private String MACDataLen;
    private String MACData;
    private String MACPaddingMethod;
    private String MACAlgorithm;
    private String MAC;

    private final static int CMD_LEN = 2;
    private final static int ENTITYID_LEN = 8;
    private final static int MODE_LEN = 1;
    private final static int PINBLOCK_LEN = 16;
    private final static int PAN_LEN = 19;
    private final static int PVKI_LEN = 1;
    private final static int PVV_LEN = 4;
    private final static int EXPRDATE_LEN = 4;
    private final static int SVCCODE_LEN = 3;
    private final static int CVV_LEN = 3;
    private final static int MAC_ALGO_LEN = 1;
    private final static int MAC_PM_LEN = 1;
    private final static int MAC_LEN = 8;
    private final static int MAC_DATA_LEN_LEN = 3;

    public CmdBean(String data) throws CmdException {
        if (data.length() < 5)
            throw new CmdException("Invalid length");
        int offset = REQ_HEADER.length();
        Command = data.substring(offset, offset + CMD_LEN);
        offset += CMD_LEN;

        switch (Command) {
            case INIT_TMK:
                if (data.length() < offset + ENTITYID_LEN)
                    throw new CmdException("Invalid ATM ID Length");
                ATMID = data.substring(offset, offset + ENTITYID_LEN);
                offset += ENTITYID_LEN;
                break;
            case EXCH_TXK:
                if (data.length() < offset + MODE_LEN)
                    throw new CmdException("Invalid MODE Length");
                Mode = data.substring(offset, offset + MODE_LEN);
                offset += MODE_LEN;

                if (data.length() < offset + ENTITYID_LEN)
                    throw new CmdException("Invalid ATM ID Length");
                ATMID = data.substring(offset, offset + ENTITYID_LEN);
                offset += ENTITYID_LEN;
                break;
            case TRNS_PIN:
                if (data.length() < offset + ENTITYID_LEN)
                    throw new CmdException("Invalid ATM ID Length");
                ATMID = data.substring(offset, offset + ENTITYID_LEN);
                offset += ENTITYID_LEN;

                if (data.length() < offset + ENTITYID_LEN)
                    throw new CmdException("Invalid ZPK Entity ID Length");
                EntityID = data.substring(offset, offset + ENTITYID_LEN);
                offset += ENTITYID_LEN;

                if (data.length() < offset + PINBLOCK_LEN)
                    throw new CmdException("Invalid PIN Block Length");
                PINBlock = data.substring(offset, offset + PINBLOCK_LEN);
                offset += PINBLOCK_LEN;
                break;
            case CLR_PIN:
                if (data.length() < offset + ENTITYID_LEN)
                    throw new CmdException("Invalid ATM ID Length");
                ATMID = data.substring(offset, offset + ENTITYID_LEN);
                offset += ENTITYID_LEN;

                if (data.length() < offset + PAN_LEN)
                    throw new CmdException("Invalid PAN Length");
                Pan = data.substring(offset, offset + PAN_LEN);
                offset += PAN_LEN;

                if (data.length() < offset + PINBLOCK_LEN)
                    throw new CmdException("Invalid PIN Block Length");
                PINBlock = data.substring(offset, offset + PINBLOCK_LEN);
                PINBlock.replace(':', 'A');
                PINBlock.replace(';', 'B');
                PINBlock.replace('<', 'C');
                PINBlock.replace('=', 'D');
                PINBlock.replace('>', 'E');
                PINBlock.replace('?', 'F');

                offset += PINBLOCK_LEN;
                break;
            case GEN_PVV:
                if (data.length() < offset + PVKI_LEN)
                    throw new CmdException("Invalid PVK Index Length");
                PVKI = data.substring(offset, offset + PVKI_LEN);
                offset += PVKI_LEN;

                if (data.length() < offset + PAN_LEN)
                    throw new CmdException("Invalid Pan Length");
                Pan = data.substring(offset, offset + PAN_LEN);
                offset += PAN_LEN;

                if (data.length() < offset + PINBLOCK_LEN)
                    throw new CmdException("Invalid PIN Block Length");
                PINBlock = data.substring(offset, offset + PINBLOCK_LEN);
                offset += PINBLOCK_LEN;
                break;
            case VER_PVV:
                if (data.length() < offset + PVKI_LEN)
                    throw new CmdException("Invalid PVK Index Length");
                PVKI = data.substring(offset, offset + PVKI_LEN);
                offset += PVKI_LEN;

                if (data.length() < offset + PAN_LEN)
                    throw new CmdException("Invalid Pan Length");
                Pan = data.substring(offset, offset + PAN_LEN);
                offset += PAN_LEN;

                if (data.length() < offset + PINBLOCK_LEN)
                    throw new CmdException("Invalid PIN Block Length");
                PINBlock = data.substring(offset, offset + PINBLOCK_LEN);
                offset += PINBLOCK_LEN;

                if (data.length() < offset + PVV_LEN)
                    throw new CmdException("Invalid PVV Length");
                PVV = data.substring(offset, offset + PVV_LEN);
                offset += PVV_LEN;
                break;
            case GEN_CVV:
                if (data.length() < offset + PAN_LEN)
                    throw new CmdException("Invalid Pan Length");
                Pan = data.substring(offset, offset + PAN_LEN);
                offset += PAN_LEN;

                if (data.length() < offset + EXPRDATE_LEN)
                    throw new CmdException("Invalid expire date Length");
                ExprDate = data.substring(offset, offset + EXPRDATE_LEN);
                offset += EXPRDATE_LEN;

                if (data.length() < offset + SVCCODE_LEN)
                    throw new CmdException("Invalid service code Length");
                SvcCode = data.substring(offset, offset + SVCCODE_LEN);
                offset += SVCCODE_LEN;
                break;
            case VER_CVV:
                if (data.length() < offset + PAN_LEN)
                    throw new CmdException("Invalid Pan Length");
                Pan = data.substring(offset, offset + PAN_LEN);
                offset += PAN_LEN;

                if (data.length() < offset + EXPRDATE_LEN)
                    throw new CmdException("Invalid expire date Length");
                ExprDate = data.substring(offset, offset + EXPRDATE_LEN);
                offset += EXPRDATE_LEN;

                if (data.length() < offset + SVCCODE_LEN)
                    throw new CmdException("Invalid servcie code Length");
                SvcCode = data.substring(offset, offset + SVCCODE_LEN);
                offset += SVCCODE_LEN;

                if (data.length() < offset + CVV_LEN)
                    throw new CmdException("Invalid CVV Length");
                CVV = data.substring(offset, offset + CVV_LEN);
                offset += CVV_LEN;
                break;
            case GEN_MAC:
                if (data.length() < offset + MAC_ALGO_LEN)
                    throw new CmdException("Invalid Algorithm Length");
                MACAlgorithm = data.substring(offset, offset + MAC_ALGO_LEN);
                offset += MAC_ALGO_LEN;

                if (data.length() < offset + MAC_PM_LEN)
                    throw new CmdException("Invalid Padding method Length");
                MACPaddingMethod = data.substring(offset, offset + MAC_PM_LEN);
                offset += MAC_PM_LEN;

                if (data.length() < offset + MAC_DATA_LEN_LEN)
                    throw new CmdException("Invalid Padding method Length");
                MACDataLen = data.substring(offset, offset + MAC_DATA_LEN_LEN);
                offset += MAC_DATA_LEN_LEN;

                MACData = data.substring(offset);
                offset += MACData.length();
                break;
            case VER_MAC:
                if (data.length() < offset + MAC_ALGO_LEN)
                    throw new CmdException("Invalid Algorithm Length");
                MACAlgorithm = data.substring(offset, offset + MAC_ALGO_LEN);
                offset += MAC_ALGO_LEN;

                if (data.length() < offset + MAC_PM_LEN)
                    throw new CmdException("Invalid Padding method Length");
                MACPaddingMethod = data.substring(offset, offset + MAC_PM_LEN);
                offset += MAC_PM_LEN;

                if (data.length() < offset + MAC_DATA_LEN_LEN)
                    throw new CmdException("Invalid Padding method Length");
                MACDataLen = data.substring(offset, offset + MAC_DATA_LEN_LEN);
                offset += MAC_DATA_LEN_LEN;

                MACData = data.substring(offset, offset + Integer.parseInt(MACDataLen));
                offset += Integer.parseInt(MACDataLen);

                if (data.length() < offset + MAC_LEN)
                    throw new CmdException("Invalid MAC Length");
                MAC = data.substring(offset, offset + MAC_LEN);
                offset += MAC_LEN;
                break;
            default:
                throw new CmdException("Invalid cmd" + Command);
        }

        CheckInput();

        if (data.length() != offset)
            throw new CmdException("Extra bytes following cmd:" + Command + " expecting length:" + offset
                    + ", actual length:" + data.length());
    }

    void CheckInput() throws CmdException {
        if (LOCALENTITY.equals(ATMID))
            throw new CmdException("Bad ATM ID, it can't be 99999999");

        if (LOCALENTITY.equals(EntityID))
            throw new CmdException("Bad Entity ID, it can't be 99999999");

        if (ATMID != null && ATMID.length() != ENTITYID_LEN)
            throw new CmdException("Bad ATM ID length, it shall be " + ENTITYID_LEN);

        if (EntityID != null && EntityID.length() != ENTITYID_LEN)
            throw new CmdException("Bad Entity ID length, it shall be " + ENTITYID_LEN);

        if (Mode != null && Mode.length() != MODE_LEN)
            throw new CmdException("Bad Mode length, it shall be " + MODE_LEN);

        if (PINBlock != null && PINBlock.length() != PINBLOCK_LEN)
            throw new CmdException("Bad PINBlock, it shall be " + PINBLOCK_LEN);

        if (Pan != null && Pan.length() != PAN_LEN)
            throw new CmdException("Bad PAN, it shall be " + PAN_LEN);

        if (PVV != null && PVV.length() != PVV_LEN)
            throw new CmdException("Bad PVV, it shall be " + PVV_LEN);

        if (ExprDate != null && ExprDate.length() != EXPRDATE_LEN)
            throw new CmdException("Bad ExprDate, it shall be " + EXPRDATE_LEN);

        if (SvcCode != null && SvcCode.length() != SVCCODE_LEN)
            throw new CmdException("Bad SvcCode, it shall be " + SVCCODE_LEN);

        if (CVV != null && CVV.length() != CVV_LEN)
            throw new CmdException("Bad CVV, it shall be " + PVV_LEN);

        if (MACAlgorithm != null && (!MACAlgorithm.equals("1") && !MACAlgorithm.equals("2"))) {
            throw new CmdException("Bad algorithm " + MACAlgorithm + ", only [1,2] accepted");
        }

        if (MACPaddingMethod != null && (!MACPaddingMethod.equals("1") && !MACPaddingMethod.equals("2"))) {
            throw new CmdException("Bad padding method " + MACPaddingMethod + ", only [1,2] accepted");
        }

        if (MACDataLen != null && MACData.length() != Integer.parseInt(MACDataLen)) {
            throw new CmdException("Bad MACData, expect length:" + MACDataLen + ", actual length" + MACData.length());
        }

        if (MAC != null && MAC.length() != MAC_LEN) {
            throw new CmdException("Bad MAC, expect length:" + MAC_LEN + ", actual length" + MAC.length());
        }
    }

    public String getResponse() {
        String rsp = "";
        switch (Command) {
            case INIT_TMK:
            case EXCH_TXK:
            case TRNS_PIN:
            case CLR_PIN:
            case GEN_PVV:
            case GEN_CVV:
            case GEN_MAC:
                rsp = RSP_HEADER + Command.toLowerCase() + ErrorCode + Data;
                break;
            case VER_PVV:
            case VER_CVV:
            case VER_MAC:
                rsp = RSP_HEADER + Command.toLowerCase() + ErrorCode;
                break;
        }
        return rsp;
    }
}
